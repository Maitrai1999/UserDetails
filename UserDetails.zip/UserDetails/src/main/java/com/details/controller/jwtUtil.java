package com.details.controller;

public interface jwtUtil {

	static String generateToken(String phoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

}
