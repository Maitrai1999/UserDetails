package com.details.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.details.entity.User;
import com.details.repository.UserRepository;
import com.details.service.OtpService;
import com.details.service.UserService;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {
	 @Autowired
    private final UserService userService;
    private final OtpService otpService;
    private final UserRepository userRepository;

   
    public UserController(UserService userService, OtpService otpService, UserRepository userRepository) {
        this.userService = userService;
        this.otpService = otpService;
		this.userRepository = userRepository;
    }
    @PostMapping(value = "/register", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String, String>> registerUser(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("companyName") String companyName,
            @RequestParam("age") int age,
            @RequestParam("dob") String dob,
            @RequestParam("phoneNumber") String phoneNumber,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        try {
            System.out.println("🔹 Received Registration Request:");
            System.out.println("Name: " + name);
            System.out.println("Email: " + email);
            System.out.println("Password: " + password);
            System.out.println("Company Name: " + companyName);
            System.out.println("Age: " + age);
            System.out.println("DOB: " + dob);
            System.out.println("Phone Number: " + phoneNumber);
            System.out.println("Profile Image: " + (image != null ? image.getOriginalFilename() : "No Image"));

            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPassword(password);
            user.setCompanyName(companyName);
            user.setAge(age);
            user.setDob(dob);
            user.setPhoneNumber(phoneNumber);

            if (image != null && !image.isEmpty()) {
                user.setProfileImage(image.getBytes());
            }

            userService.registerUser(user); // 🔹 Call save()

            return ResponseEntity.ok(Collections.singletonMap("message", "User registered successfully!"));
        } catch (IOException e) {
            return ResponseEntity.badRequest().body(Collections.singletonMap("message", "Error processing profile image: " + e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Collections.singletonMap("message", "An error occurred: " + e.getMessage()));
        }
    }


    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> loginUser(@RequestParam String email, @RequestParam String password) {
        Optional<User> optionalUser = userRepository.findByEmail(email);

        if (!optionalUser.isPresent()) {
            return ResponseEntity.status(404).body(Collections.singletonMap("message", "User not found"));
        }

        User user = optionalUser.get();

        if (!user.getPassword().equals(password)) {
            return ResponseEntity.status(401).body(Collections.singletonMap("message", "Invalid credentials"));
        }

        // Generate OTP for authentication
        try {
            otpService.generateOtp(user.getPhoneNumber());

            // ✅ Ensure correct JSON response format
            Map<String, Object> response = new HashMap<>();
            response.put("message", "OTP sent successfully.");
            response.put("requiresOtp", true); 

            return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, "application/json") // ✅ Ensure JSON content type
                .body(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500)
                .header(HttpHeaders.CONTENT_TYPE, "application/json") // ✅ Ensure JSON content type
                .body(Collections.singletonMap("message", "Error sending OTP. Please try again."));
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, String>> verifyOtp(@RequestBody Map<String, String> requestBody) {
        String email = requestBody.get("email");
        String otp = requestBody.get("otp");

        Map<String, String> response = new HashMap<>();

        if (email == null || otp == null || email.isEmpty() || otp.isEmpty()) {
            response.put("message", "Email and OTP are required.");
            return ResponseEntity.badRequest().body(response);
        }

        Optional<User> userOptional = userRepository.findByEmail(email);
        if (!userOptional.isPresent()) {
            response.put("message", "User not found.");
            return ResponseEntity.status(404).body(response);
        }

        User user = userOptional.get();
        if (otpService.verifyOtp(user.getPhoneNumber(), otp)) {
            response.put("message", "OTP verified. Redirecting to dashboard...");
            response.put("token", "your_generated_jwt_token"); // Replace with actual token
            return ResponseEntity.ok(response);
        } else {
            response.put("message", "Invalid OTP");
            return ResponseEntity.status(401).body(response);
        }
    }


    @DeleteMapping("/delete")
    public ResponseEntity<Map<String, String>> deleteUser(@RequestParam String email) {
        Optional<User> user = userRepository.findByEmail(email);
        if (user.isPresent()) {
            userRepository.delete(user.get());
            return ResponseEntity.ok(Collections.singletonMap("message", "User deleted successfully!"));
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.singletonMap("message", "User email not found!"));
        }
    }

}

