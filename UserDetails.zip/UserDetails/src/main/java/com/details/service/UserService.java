package com.details.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.details.entity.User;
import com.details.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {
	 @Autowired
	    private UserRepository userRepository;


	    public User registerUser(User user) {
	        System.out.println("🔹 Saving User: " + user.toString()); // Debug Log
	        return userRepository.save(user);
	    }
	    public Optional<User> findByEmail(String email) {
	        return userRepository.findByEmail(email);
	    }
	    @Transactional
	    public String deleteUser(String email) {
	        Optional<User> user = userRepository.findByEmail(email);
	        if (user.isPresent()) {
	            userRepository.deleteByEmail(email);
	            return "User deleted successfully!";
	        }
	        return "User not found!";
	    }
}