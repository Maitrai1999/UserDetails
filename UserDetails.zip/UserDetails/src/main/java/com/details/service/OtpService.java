package com.details.service;

import com.details.entity.User;
import com.details.repository.UserRepository;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.Random;

@Service
public class OtpService {

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.phone.number}")
    private String fromPhoneNumber;

    @Autowired
    
    private final UserRepository userRepository;

    public OtpService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public String generateOtp(String phoneNumber) {
        try {
            System.out.println("Twilio SID: " + accountSid);
            System.out.println("Twilio Token: " + authToken);

            Twilio.init(accountSid, authToken); 
            String otp = String.valueOf(new Random().nextInt(900000) + 100000);

            Optional<User> optionalUser = userRepository.findByPhoneNumber(phoneNumber);
            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                user.setOtp(otp);
                userRepository.save(user);

                Message.creator(
                    new PhoneNumber(phoneNumber),
                    new PhoneNumber(fromPhoneNumber),
                    "Your OTP is: " + otp
                ).create();

                return "OTP sent successfully!";
            } else {
                return "User not found!";
            }
        } catch (Exception e) {
            return "Error sending OTP: " + e.getMessage();
        }
    }

    public boolean verifyOtp(String phoneNumber, String enteredOtp) {
        Optional<User> optionalUser = userRepository.findByPhoneNumber(phoneNumber);
        
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();

            // Check if OTP exists and matches
            if (user.getOtp() != null && Objects.equals(user.getOtp(), enteredOtp)) {
                
                // Optional: Check if OTP has expired
                if (user.getOtpExpiry() != null && ((LocalDateTime) user.getOtpExpiry()).isBefore(LocalDateTime.now())) {
                    return false; // OTP expired
                }

                user.setVerified(true);
                user.setOtp(null); // Clear OTP after successful verification
                user.setOtpExpiry(null); // Clear expiration time
                userRepository.save(user);
                return true;
            }
        }

        return false; // Invalid OTP
    }

}
